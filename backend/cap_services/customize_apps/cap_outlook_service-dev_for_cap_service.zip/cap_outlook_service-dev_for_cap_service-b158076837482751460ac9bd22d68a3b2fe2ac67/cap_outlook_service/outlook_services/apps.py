from django.apps import AppConfig


class OutlookServicesConfig(AppConfig):
    name = 'outlook_services'
